# E-commerce-data-analysis
파이썬을 활용한 이커머스 데이터 분석
주피터 노트북으로 작성한 파일이 커서 Sorry, something went wrong. Reload? 으로 보일때 아래 링크를 통해 주피터 노트북으로 작성한 파일을 볼수있습니다~!! 
https://nbviewer.jupyter.org/github/SEONGJAE-YOO/E-commerce-data-analysis/tree/main/

![fastcampus-수료증명서-이커머스데이터분석 (2)_page-0001](https://user-images.githubusercontent.com/54341259/148302714-9f85d682-9cdd-464b-8917-7d5c8b9b04be.jpg)
