# AladinCrawler
"Aladin" korean online book shop info crawler for so.prize<br>
reference code : https://wooiljeong.github.io/python/yes24_crawling_03/
